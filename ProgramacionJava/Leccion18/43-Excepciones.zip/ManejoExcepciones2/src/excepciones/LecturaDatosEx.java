/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package excepciones;

/**
 *
 * @author almis
 */
public class LecturaDatosEx extends AccesoDatosEx{
    
    public LecturaDatosEx(String message) {
        super(message);
    }
    
}
